package eu.vranckaert.episodeWatcher.preferences;

public class PreferencesKeys {
    public static final String EPISODE_SORTING_KEY = "episode_sorting_order";
    public static final String WATCH_SHOW_SORTING_KEY = "watch_show_sorting_order";
    public static final String ACQUIRE_SHOW_SORTING_KEY = "acquire_show_sorting_order";
    public static final String COMING_SHOW_SORTING_KEY = "coming_show_sorting_order";
    public static final String RUNTIME_SHOW_SORTING_KEY = "runtime_show_sorting_order";
    public static final String OPEN_DEFAULT_TAB_KEY = "open_default_tab";
    public static final String ACQUIRE_KEY = "acquire_settings";
    public static final String THEME_KEY = "theme_key";
    public static final String STORE_PASSWORD_KEY = "store_password";
    public static final String LANGUAGE_KEY = "language";
    public static final String APPLICATION_VERSION_KEY = "app_version";
    public static final String DAYS_BACKWARDCP = "days_BackwardCP";
    public static final String DAYS_BACKWARD_ENABLED_KEY = "Days_Backward_Enabled";
    public static final String DISABLE_ACQUIRE = "disable_acquire";
    public static final String DISABLE_COMING = "disable_coming";
    public static final String CACHE_EPISODES_ENABLED_KEY = "Cache Episodes Enabled";
    public static final String CACHE_EPISODES_CACHE_AGE = "Episodes Cache Age";
    public static final String RUNTIME_ENABLED_KEY = "Series Runtime Enabled";
    public static final String SHOW_LISTING_UNACQUIRED_KEY = "List Unacquired Shows";
    public static final String SHOW_LISTING_UNWATCHED_KEY = "List Unwatched Shows";
    public static final String SHOW_LISTING_IGNORED_KEY = "List Ignored Shows";
    public static final String SHOW_LISTING_PILOTS_KEY = "List Pilots Shows";
    public static final String SHOW_LISTING_LOCALIZED_AIRDATES_KEY = "List Localized Airdate Shows";
}
